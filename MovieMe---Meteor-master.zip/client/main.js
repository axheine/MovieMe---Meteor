

/*
Ici import du fichier client startup : c'est le main coté client
*/
import '../imports/startup/client/index.js';