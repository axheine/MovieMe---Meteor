

/*
Fichier ne contenant que les imports des fichiers startup, pour g�rer leur ordre d'import
*/
import './routing.js';